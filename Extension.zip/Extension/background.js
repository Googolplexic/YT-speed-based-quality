chrome.runtime.onInstalled.addListener(() => {
    console.log("YouTube Quality Adjuster installed.");
});